import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountService } from 'src/app/services/account.service';

@Component({
  selector: 'app-account-details',
  templateUrl: './account-details.component.html',
  styleUrls: ['./account-details.component.css']
})
export class AccountDetailsComponent implements OnInit {
  data:any;
  id = 0;
    constructor(private accountService:AccountService,private _router: Router,private _route: ActivatedRoute) { }
  
    ngOnInit(): void {
      this._route.queryParams.subscribe(params => {
        this.id = params['id'];
        console.log(this.id); // Print the parameter to the console. 
    });
  
       if(this.id >= 1){
        this.accountService.getAccount(this.id).subscribe(
          (data: any) => {
            this.data = data.content;
            console.log(this.data);
          },
          (error) => {
            console.log(error);
          }
        );
       }
    }
  
  }
  