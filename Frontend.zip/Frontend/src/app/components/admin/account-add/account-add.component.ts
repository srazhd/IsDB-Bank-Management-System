import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountService } from 'src/app/services/account.service';
import { BranchService } from 'src/app/services/branch.service';
import { CustomerService } from 'src/app/services/customer.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-account-add',
  templateUrl: './account-add.component.html',
  styleUrls: ['./account-add.component.css']
})
export class AccountAddComponent implements OnInit {
  branchs = [];
  customers = [];
  data = {
    "accountInfo": {
      "name": "",
    },
    "branch": {
      "id": 0,
    },
    "customer": {
      "id": 0,
    },
    "address": {
      "streetName": "",
      "city": "",
      "country": "",
      "zipCode": ""
    }

  };
  id = 0;
  isEdit = false;
  constructor(private accountService: AccountService, private customerService: CustomerService, private branchService: BranchService, private _router: Router, private _route: ActivatedRoute) {

  }

  ngOnInit(): void {

    this.branchService.branchs().subscribe((data: any) => {
      this.branchs = data.content;
      console.log(data.content);
    })
    this.customerService.customers().subscribe((data: any) => {
      this.customers = data.content;
      console.log(data.content);
    })



    this._route.queryParams.subscribe(params => {
      this.id = params['id'];
      console.log(this.id); // Print the parameter to the console. 
    });

    if (this.id >= 1) {
      this.accountService.getAccount(this.id).subscribe(
        (data: any) => {

          this.data.accountInfo = data.content.accountInfo;
          this.data.branch.id = data.content.branId;
          this.data.customer.id = data.content.custId;
          this.data.address = data.content.address;
          this.isEdit = true;
          console.log(this.data);
        },
        (error) => {
          console.log(error);
        }
      );
    }


  }
  onSubmit() {
    if (!this.isEdit) {
      // console.log(this.data);
      this.accountService.addAccount(this.data).subscribe(
        (data) => {
          Swal.fire('Success', 'Account is added', 'success');
          this.data = {
            "accountInfo": {
              "name": " ",
            },
            "branch": {
              "id": 0,
            },
            "customer": {
              "id": 0,
            },
            "address": {
              "streetName": " ",
              "city": " ",
              "country": " ",
              "zipCode": " "
            },
          };
        },

        (error) => {
          Swal.fire('Error!! ', 'Error while adding account', 'error');
          console.log(error);
        }
      );
    } else if (this.isEdit) {

      this.accountService.updateAccount(this.id, this.data).subscribe(
        (data) => {
          Swal.fire('Success', 'Branch is updated', 'success');
          this.data = {
            "accountInfo": {
              "name": "",
            },
            "branch": {
              "id": 0,
            },
            "customer": {
              "id": 0,
            },
            "address": {
              "streetName": "",
              "city": "",
              "country": "",
              "zipCode": ""
            },
          };
        },

        (error) => {
          Swal.fire('Error!! ', 'Error while update Branch', 'error');
          console.log(error);
        }
      );
    }



  }

}
