import { Component, OnInit } from '@angular/core';
import { CustomerService } from 'src/app/services/customer.service';
 
import Swal from 'sweetalert2';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {

  customers=[];
  constructor(private customerService :CustomerService ) { }

  ngOnInit(): void {
    this.customerService.customers().subscribe((data:any)=>{
      this.customers= data.content;
      console.log(data.content);
   })
  }
  edit(customer){

  }
  delete(id){
    this.customerService.deleteCustomer(id).subscribe(
      (data) => {
        Swal.fire('Success', 'Customer id deleted', 'success');
        
      },

      (error) => {
        Swal.fire('Error!! ', 'Error while delete customer', 'error');
        console.log(error);
      }
     );
  }

}
