import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountInfoService } from 'src/app/services/account-info.service';
import { TransferService } from 'src/app/services/transfer.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-transferadd',
  templateUrl: './transferadd.component.html',
  styleUrls: ['./transferadd.component.css']
})
export class TransferaddComponent implements OnInit {
  data = {
    "accountInfoFrom": {
          "id": "",
          "name": ""
     },
     "accountInfoTo": {
      "id": "",
      "name": ""
     },
      "date":"",
      "amount":""
      
  };
  id = 0;
  isEdit = false;
    constructor(private accountInfoService :AccountInfoService,private transferService :TransferService,private _router: Router,private _route: ActivatedRoute) {
  
     }
    
    ngOnInit(): void {
      this._route.queryParams.subscribe(params => {
        this.id = params['id'];
        console.log(this.id); // Print the parameter to the console. 
    });
  
       if(this.id >= 1){
        this.transferService.getTransfer(this.id).subscribe(
          (data: any) => {
            this.data.date = data.content.date;
            this.data.amount = data.content.amount;
            this.isEdit =true;
            console.log(this.data);
  
            this.accountInfoService.getAccountInfo(data.content.acIdFrom).subscribe(
              (data:any) => {
                this.data.accountInfoFrom.id= data.content.id;
                this.data.accountInfoFrom.name = data.content.name;
              },
        
              (error) => {
                Swal.fire('Error!! ', 'Error while adding Get Account No And Name', 'error');
                console.log(error);
              }
             );
             this.accountInfoService.getAccountInfo(data.content.acIdTo).subscribe(
              (data:any) => {
                this.data.accountInfoTo.id= data.content.id;
                this.data.accountInfoTo.name = data.content.name;
              },
        
              (error) => {
                Swal.fire('Error!! ', 'Error while adding Get Account No And Name', 'error');
                console.log(error);
              }
             );
  
          },
          (error) => {
            console.log(error);
          }
        );
       }
      
      
    }
    getAccountNameFrom(id){
       this.accountInfoService.getAccountInfo(id).subscribe(
        (data:any) => {
          this.data.accountInfoFrom.name = data.content.name;
        },
  
        (error) => {
          Swal.fire('Error!! ', 'Error while adding Get Ac Name', 'error');
          console.log(error);
        }
       );
       
    }
    getAccountNameTo(id){
      this.accountInfoService.getAccountInfo(id).subscribe(
       (data:any) => {
         this.data.accountInfoTo.name = data.content.name;
       },
 
       (error) => {
         Swal.fire('Error!! ', 'Error while adding Get Ac Name', 'error');
         console.log(error);
       }
      );
      
   }
  
    onSubmit(){
    if(!this.isEdit){
  
      this.transferService.addTransfer(this.data).subscribe(
        (data) => {
          Swal.fire('Success', 'Transfer is added', 'success');
          this.data = {
            "accountInfoFrom": {
              "id": " ",
              "name": " "
         },
         "accountInfoTo": {
          "id": " ",
          "name": " "
         },
          "date":" ",
          "amount":" "
          };
        },
  
        (error) => {
          Swal.fire('Error!! ', 'Error while adding Transfer', 'error');
          console.log(error);
        }
       );
      }else if(this.isEdit){
         
        this.transferService.updateTransfer(this.id, this.data ).subscribe(
          (data) => {
            Swal.fire('Success', 'Transfer is updated', 'success');
            this.data = {
              "accountInfoFrom": {
                "id": " ",
                "name": " "
           },
           "accountInfoTo": {
            "id": " ",
            "name": " "
           },
            "date":" ",
            "amount":" "
            };
          },
    
          (error) => {
            Swal.fire('Error!! ', 'Error while update Transfer', 'error');
            console.log(error);
          }
         );
      }
  
  
    
    }
  
  }