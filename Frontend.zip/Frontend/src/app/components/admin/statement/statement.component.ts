import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountInfoService } from 'src/app/services/account-info.service';
import { AccountService } from 'src/app/services/account.service';
import { DepositService } from 'src/app/services/deposit.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-statement',
  templateUrl: './statement.component.html',
  styleUrls: ['./statement.component.css']
})
export class StatementComponent implements OnInit {
  data = {
    "id":0,
    "accountInfo": {
          "id": "",
          "name": ""
     },
       
      "amount":"",
      "address": {
        "streetName": "",
        "city": "",
        "country": "",
        "zipCode": ""
    },
    sdate:[]

      
  };
  isStatement = false;
  
   
  
  constructor(private accountInfoService :AccountInfoService,private accountService :AccountService,private depositService :DepositService,private _router: Router,private _route: ActivatedRoute) {
     
   }

  ngOnInit(): void {
  
  }
  getAccountName(id){
    this.accountInfoService.getAccountInfo(id).subscribe(
     (data:any) => {
       this.data.accountInfo.name = data.content.name;
       this.data.amount = data.content.totalBalance;
       this.data.sdate = data.content.statementDataDtos;

       this.accountService.getAccountByAcno(data.content.id).subscribe(
        (data:any) => {
          console.log(data);
          this.data.id = data.content.id;
          this.data.address.streetName = data.content.address.streetName;
          this.data.address.city = data.content.address.streetName;
          this.data.address.country = data.content.address.country;
          this.data.address.zipCode = data.content.address.zipCode;
          this.isStatement = true;
        },
   
        (error) => {
          Swal.fire('Error!! ', 'Error while adding Get Ac Name', 'error');
          console.log(error);
        }
       );





     },

     (error) => {
       Swal.fire('Error!! ', 'Error while adding Get Ac Name', 'error');
       console.log(error);
     }
    );
    
 }
 onSubmit(){
  this.getAccountName(this.data.accountInfo.id);
 }
 onPrint(divName) {
  const printContents = document.getElementById(divName).innerHTML;
  const originalContents = document.body.innerHTML;
  document.body.innerHTML = printContents;
  window.print();
  document.body.innerHTML = originalContents;
}
}
