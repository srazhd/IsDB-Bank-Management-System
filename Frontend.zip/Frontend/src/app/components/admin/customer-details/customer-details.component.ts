import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomerService } from 'src/app/services/customer.service';

@Component({
  selector: 'app-customer-details',
  templateUrl: './customer-details.component.html',
  styleUrls: ['./customer-details.component.css']
})
export class CustomerDetailsComponent implements OnInit {
  data:any;
  id = 0;
    constructor(private customerService:CustomerService,private _router: Router,private _route: ActivatedRoute) { }
  
    ngOnInit(): void {
      this._route.queryParams.subscribe(params => {
        this.id = params['id'];
        console.log(this.id); // Print the parameter to the console. 
    });
  
       if(this.id >= 1){
        this.customerService.getCustomer(this.id).subscribe(
          (data: any) => {
            this.data = data.content;
            console.log(this.data);
          },
          (error) => {
            console.log(error);
          }
        );
       }
    }
  
  }
  