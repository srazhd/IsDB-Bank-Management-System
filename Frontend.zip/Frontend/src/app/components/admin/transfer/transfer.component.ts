import { Component, OnInit } from '@angular/core';
import { AccountInfoService } from 'src/app/services/account-info.service';

import { TransferService } from 'src/app/services/transfer.service';
 
import Swal from 'sweetalert2';

@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.css']
})
export class TransferComponent implements OnInit {


  transfers=[];
  constructor(private accountInfoService :AccountInfoService,private transferService :TransferService) { }

  ngOnInit(): void {
    this.transferService.transfers().subscribe((data:any)=>{
      this.transfers= data.content;
      console.log(data.content);
   })
  }
  edit(transfer){

  }
  delete(id){
    this.transferService.deleteTransfer(id).subscribe(
      (data) => {
        Swal.fire('Success', 'Transfer id deleted', 'success');
        
      },

      (error) => {
        Swal.fire('Error!! ', 'Error while delete transfer', 'error');
        console.log(error);
      }
     );
  }

}


