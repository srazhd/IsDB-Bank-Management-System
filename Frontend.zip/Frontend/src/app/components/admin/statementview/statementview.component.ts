import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-statementview',
  templateUrl: './statementview.component.html',
  styleUrls: ['./statementview.component.css']
})
export class StatementviewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
