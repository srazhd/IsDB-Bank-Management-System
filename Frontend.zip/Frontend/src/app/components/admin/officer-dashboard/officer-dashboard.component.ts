import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-officer-dashboard',
  templateUrl: './officer-dashboard.component.html',
  styleUrls: ['./officer-dashboard.component.css']
})
export class OfficerDashboardComponent implements OnInit {
  user = null;
  constructor(private snack: MatSnackBar,
    private login: LoginService,
    private router: Router) {}

  ngOnInit(): void {
    this.user = this.login.getUser();
     
  }
  logout(){
    this.login.logout();
    this.router.navigate(['login']);
  }
}
