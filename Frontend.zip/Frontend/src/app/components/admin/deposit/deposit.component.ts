import { Component, OnInit } from '@angular/core';
import { AccountInfoService } from 'src/app/services/account-info.service';

import { DepositService } from 'src/app/services/deposit.service';
 
import Swal from 'sweetalert2';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {


  deposits=[];
  constructor(private accountInfoService :AccountInfoService,private depositService :DepositService) { }

  ngOnInit(): void {
    this.depositService.deposits().subscribe((data:any)=>{
      this.deposits= data.content;
      console.log(data.content);
   })
  }
  edit(deposit){

  }
  delete(id){
    this.depositService.deleteDeposit(id).subscribe(
      (data) => {
        Swal.fire('Success', 'Deposit id deleted', 'success');
        
      },

      (error) => {
        Swal.fire('Error!! ', 'Error while delete deposit', 'error');
        console.log(error);
      }
     );
  }

}

