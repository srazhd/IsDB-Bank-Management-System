import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountInfoService } from 'src/app/services/account-info.service';
import { DepositService } from 'src/app/services/deposit.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-depositadd',
  templateUrl: './depositadd.component.html',
  styleUrls: ['./depositadd.component.css']
})
export class DepositaddComponent implements OnInit {
  data = {
  "accountInfo": {
        "id": "",
        "name": ""
   },
    "date":"",
    "amount":""
    
};
id = 0;
isEdit = false;
  constructor(private accountInfoService :AccountInfoService,private depositService :DepositService,private _router: Router,private _route: ActivatedRoute) {

   }
  
  ngOnInit(): void {
    this._route.queryParams.subscribe(params => {
      this.id = params['id'];
      console.log(this.id); // Print the parameter to the console. 
  });

     if(this.id >= 1){
      this.depositService.getDeposit(this.id).subscribe(
        (data: any) => {
          this.data.date = data.content.date;
          this.data.amount = data.content.amount;
          this.isEdit =true;
          console.log(this.data);

          this.accountInfoService.getAccountInfo(data.content.acId).subscribe(
            (data:any) => {
              this.data.accountInfo.id= data.content.id;
              this.data.accountInfo.name = data.content.name;
            },
      
            (error) => {
              Swal.fire('Error!! ', 'Error while adding Get Account No And Name', 'error');
              console.log(error);
            }
           );

        },
        (error) => {
          console.log(error);
        }
      );
     }
    
    
  }
  getAccountName(id){
     this.accountInfoService.getAccountInfo(id).subscribe(
      (data:any) => {
        this.data.accountInfo.name = data.content.name;
      },

      (error) => {
        Swal.fire('Error!! ', 'Error while adding Get Ac Name', 'error');
        console.log(error);
      }
     );
     
  }

  onSubmit(){
  if(!this.isEdit){

    this.depositService.addDeposit(this.data).subscribe(
      (data) => {
        Swal.fire('Success', 'Deposit is added', 'success');
        this.data = {
          "accountInfo": {
            "id": " ",
            "name": " "
       },
        "date":" ",
        "amount":" "
        };
      },

      (error) => {
        Swal.fire('Error!! ', 'Error while adding Deposit', 'error');
        console.log(error);
      }
     );
    }else if(this.isEdit){
       
      this.depositService.updateDeposit(this.id, this.data ).subscribe(
        (data) => {
          Swal.fire('Success', 'Deposit is updated', 'success');
          this.data = {
            "accountInfo": {
              "id": " ",
              "name": " "
         },
          "date":" ",
          "amount":" "
          };
        },
  
        (error) => {
          Swal.fire('Error!! ', 'Error while update Deposit', 'error');
          console.log(error);
        }
       );
    }


  
  }

}

