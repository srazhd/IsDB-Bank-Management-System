import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CustomerService } from 'src/app/services/customer.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-customer-add',
  templateUrl: './customer-add.component.html',
  styleUrls: ['./customer-add.component.css']
})
export class CustomerAddComponent implements OnInit {
  data = {
    "name": "",
    "fatherName":"",
    "motherName":"",
    "spousName":"",
    "email": "",
    "phone": "",
    "nid": "",
    "dob": "",
    "address": {
        "streetName": "",
        "city": "",
        "country": "",
        "zipCode": ""
    },
    
};
id = 0;
isEdit = false;
  constructor(private customerService :CustomerService,private _router: Router,private _route: ActivatedRoute) {

   }
  
  ngOnInit(): void {
    this._route.queryParams.subscribe(params => {
      this.id = params['id'];
      console.log(this.id); // Print the parameter to the console. 
  });

     if(this.id >= 1){
      this.customerService.getCustomer(this.id).subscribe(
        (data: any) => {
          this.data = data.content;
          this.isEdit =true;
          console.log(this.data);
        },
        (error) => {
          console.log(error);
        }
      );
     }
    
    
  }
  onSubmit(){
  if(!this.isEdit){

    this.customerService.addCustomer(this.data).subscribe(
      (data) => {
        Swal.fire('Success', 'Customer is added', 'success');
        this.data = {
          "name": " ",
          "fatherName":" ",
          "motherName":" ",
          "spousName":" ",
          "email": " ",
          "phone": " ",
          "nid": " ",
          "dob": " ",
          "address": {
              "streetName": " ",
              "city": " ",
              "country": " ",
              "zipCode": " "
          },
        };
      },

      (error) => {
        Swal.fire('Error!! ', 'Error while adding Customer', 'error');
        console.log(error);
      }
     );
    }else if(this.isEdit){
       
      this.customerService.updateCustomer(this.id, this.data ).subscribe(
        (data) => {
          Swal.fire('Success', 'Customer is updated', 'success');
          this.data = {
            "name": " ",
            "fatherName":" ",
            "motherName":" ",
            "spousName":" ",
            "email": " ",
            "phone": " ",
            "nid": " ",
            "dob": " ",
            "address": {
                "streetName": " ",
                "city": " ",
                "country": " ",
                "zipCode": " "
            },
          };
        },
  
        (error) => {
          Swal.fire('Error!! ', 'Error while update Customer', 'error');
          console.log(error);
        }
       );
    }


  
  }

}
