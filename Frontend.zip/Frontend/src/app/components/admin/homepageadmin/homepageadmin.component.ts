import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homepageadmin',
  templateUrl: './homepageadmin.component.html',
  styleUrls: ['./homepageadmin.component.css']
})
export class HomepageadminComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
