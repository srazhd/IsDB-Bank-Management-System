import { Component, OnInit } from '@angular/core';
import { AccountInfoService } from 'src/app/services/account-info.service';

import { WithdrawService } from 'src/app/services/withdraw.service';
 
import Swal from 'sweetalert2';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {

  withdraws=[];
  constructor(private accountInfoService :AccountInfoService,private withdrawService :WithdrawService) { }

  ngOnInit(): void {
    this.withdrawService.withdraws().subscribe((data:any)=>{
      this.withdraws= data.content;
      console.log(data.content);
   })
  }
  edit(withdraw){

  }
  delete(id){
    this.withdrawService.deleteWithdraw(id).subscribe(
      (data) => {
        Swal.fire('Success', 'Withdraw id deleted', 'success');
        
      },

      (error) => {
        Swal.fire('Error!! ', 'Error while delete withdraw', 'error');
        console.log(error);
      }
     );
  }

}

