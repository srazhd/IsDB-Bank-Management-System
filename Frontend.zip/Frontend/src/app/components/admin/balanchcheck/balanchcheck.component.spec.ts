import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BalanchcheckComponent } from './balanchcheck.component';

describe('BalanchcheckComponent', () => {
  let component: BalanchcheckComponent;
  let fixture: ComponentFixture<BalanchcheckComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BalanchcheckComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BalanchcheckComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
