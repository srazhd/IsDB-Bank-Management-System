import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountInfoService } from 'src/app/services/account-info.service';
import { DepositService } from 'src/app/services/deposit.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-balanchcheck',
  templateUrl: './balanchcheck.component.html',
  styleUrls: ['./balanchcheck.component.css']
})
export class BalanchcheckComponent implements OnInit {
  data = {
    "accountInfo": {
          "id": "",
          "name": ""
     },
       
      "amount":""
      
  };
  constructor(private accountInfoService :AccountInfoService,private depositService :DepositService,private _router: Router,private _route: ActivatedRoute) { }

  ngOnInit(): void {
  }
  getAccountName(id){
    this.accountInfoService.getAccountInfo(id).subscribe(
     (data:any) => {
       this.data.accountInfo.name = data.content.name;
       this.data.amount = data.content.totalBalance;
     },

     (error) => {
       Swal.fire('Error!! ', 'Error while adding Get Ac Name', 'error');
       console.log(error);
     }
    );
    
 }
 onSubmit(){
  this.getAccountName(this.data.accountInfo.id);
 }
}
