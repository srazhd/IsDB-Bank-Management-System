import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountInfoService } from 'src/app/services/account-info.service';
import { WithdrawService } from 'src/app/services/withdraw.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-withdrawadd',
  templateUrl: './withdrawadd.component.html',
  styleUrls: ['./withdrawadd.component.css']
})
export class WithdrawaddComponent implements OnInit {
  data = {
    "accountInfo": {
          "id": "",
          "name": ""
     },
      "date":"",
      "amount":""
      
  };
  id = 0;
  isEdit = false;
    constructor(private accountInfoService :AccountInfoService,private withdrawService :WithdrawService,private _router: Router,private _route: ActivatedRoute) {
  
     }
    
    ngOnInit(): void {
      this._route.queryParams.subscribe(params => {
        this.id = params['id'];
        console.log(this.id); // Print the parameter to the console. 
    });
  
       if(this.id >= 1){
        this.withdrawService.getWithdraw(this.id).subscribe(
          (data: any) => {
            this.data.date = data.content.date;
            this.data.amount = data.content.amount;
            this.isEdit =true;
            console.log(this.data);
  
            this.accountInfoService.getAccountInfo(data.content.acId).subscribe(
              (data:any) => {
                this.data.accountInfo.id= data.content.id;
                this.data.accountInfo.name = data.content.name;
              },
        
              (error) => {
                Swal.fire('Error!! ', 'Error while adding Get Account No And Name', 'error');
                console.log(error);
              }
             );
  
          },
          (error) => {
            console.log(error);
          }
        );
       }
      
      
    }
    getAccountName(id){
       this.accountInfoService.getAccountInfo(id).subscribe(
        (data:any) => {
          this.data.accountInfo.name = data.content.name;
        },
  
        (error) => {
          Swal.fire('Error!! ', 'Error while adding Get Ac Name', 'error');
          console.log(error);
        }
       );
       
    }
  
    onSubmit(){
    if(!this.isEdit){
  
      this.withdrawService.addWithdraw(this.data).subscribe(
        (data) => {
          Swal.fire('Success', 'Withdraw is added', 'success');
          this.data = {
            "accountInfo": {
              "id": " ",
              "name": " "
         },
          "date":" ",
          "amount":" "
          };
        },
  
        (error) => {
          Swal.fire('Error!! ', 'Error while adding Withdraw', 'error');
          console.log(error);
        }
       );
      }else if(this.isEdit){
         
        this.withdrawService.updateWithdraw(this.id, this.data ).subscribe(
          (data) => {
            Swal.fire('Success', 'Withdraw is updated', 'success');
            this.data = {
              "accountInfo": {
                "id": " ",
                "name": " "
           },
            "date":" ",
            "amount":" "
            };
          },
    
          (error) => {
            Swal.fire('Error!! ', 'Error while update Withdraw', 'error');
            console.log(error);
          }
         );
      }
  
  
    
    }
  
  }
  
  