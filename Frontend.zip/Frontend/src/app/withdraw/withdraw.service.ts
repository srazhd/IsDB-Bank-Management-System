import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Withdraw } from '../models/withdraw.model';
import { Observable } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';
 
const httpOptions = {
    headers: new HttpHeaders({
      'Content-Type':  'application/json',
      'Authorization': 'my-auth-token'
    })
  };
@Injectable({
    providedIn: 'root'
})
export class WithdrawService {

 

    LIVE_URI = 'http://localhost:3000';
    constructor(private httpClient: HttpClient) { }
    // getWithdraws() {
    //     return this.httpClient.get(`${this.LIVE_URI}/Withdraws`);
    // }

    getWithdraws(): Observable<Withdraw[]> {
        return this.httpClient.get<Withdraw[]>(`${this.LIVE_URI}/Withdraws`);
    }
    addWithdraw(u: Withdraw | null) {

        this.httpClient.post(`${this.LIVE_URI}/Withdraws`, u)
            .subscribe(           );

            
    }

  

    /** PUT: update the hero on the server. Returns the updated hero upon success. */
updateWithdraw (d: Withdraw) {
    this.httpClient.put<Withdraw>(`${this.LIVE_URI}/Withdraws/${d.id}`, d).subscribe();
}
deleteWithdraw (d: Withdraw) {
    this.httpClient.delete<Withdraw>(`${this.LIVE_URI}/Withdraws/${d.id}`).subscribe();
}

}