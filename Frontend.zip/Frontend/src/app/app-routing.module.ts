import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/pages/auth/login/login.component';
 
import { DepositComponent } from './components/admin/deposit/deposit.component';
import { WithdrawComponent } from './components/admin/withdraw/withdraw.component';
 
import { AdminGuard } from './services/admin.guard';
import { DashboardComponent } from './components/admin/dashboard/dashboard.component';
import { ProfileComponent } from './components/admin/profile/profile.component';
import { UserComponent } from './components/admin/user/user.component';
import { AdduserComponent } from './components/admin/user-add/adduser.component';
import { AddbranchComponent } from './components/admin/branch-add/addbranch.component';
import { BranchComponent } from './components/admin/branch/branch.component';
import { CustomerAddComponent } from './components/admin/customer-add/customer-add.component';
import { CustomerComponent } from './components/admin/customer/customer.component';
import { AccountAddComponent } from './components/admin/account-add/account-add.component';
import { AccountComponent } from './components/admin/account/account.component';
import { DepositaddComponent } from './components/admin/depositadd/depositadd.component';
import { WithdrawaddComponent } from './components/admin/withdrawadd/withdrawadd.component';
import { TransferaddComponent } from './components/admin/transferadd/transferadd.component';
import { TransferComponent } from './components/admin/transfer/transfer.component';
import { BranchDetailsComponent } from './components/admin/branch-details/branch-details.component';
import { AccountDetailsComponent } from './components/admin/account-details/account-details.component';
import { CustomerDetailsComponent } from './components/admin/customer-details/customer-details.component';
import { BalanchcheckComponent } from './components/admin/balanchcheck/balanchcheck.component';
import { StatementComponent } from './components/admin/statement/statement.component';
import { StatementviewComponent } from './components/admin/statementview/statementview.component';
import { OfficerGuard } from './services/officer.guard';
import { OfficerDashboardComponent } from './components/admin/officer-dashboard/officer-dashboard.component';
import { HomepageadminComponent } from './components/admin/homepageadmin/homepageadmin.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: '', redirectTo: 'admin', pathMatch: 'full' },

  {
    path: 'admin',
    component: DashboardComponent,
    canActivate: [AdminGuard],
    children: [
      { path: '', redirectTo: 'homepage', pathMatch: 'full' },
      {
        path: 'homepage',
        component: HomepageadminComponent,
      },
      {
        path: 'profile',
        component: ProfileComponent,
      },
      {
        path: 'user',
        component: UserComponent,
      },
      {
        path: 'useradd',
        component: AdduserComponent,
      }, {
        path: 'branchadd',
        component: AddbranchComponent,
      }, {
        path: 'branch',
        component: BranchComponent,
      }, {
        path: 'customeradd',
        component: CustomerAddComponent,
      }, {
        path: 'customers',
        component: CustomerComponent,
      }, {
        path: 'accountcreate',
        component: AccountAddComponent,
      }, {
        path: 'accounts',
        component: AccountComponent,
      }, {
        path: 'depositadd',
        component: DepositaddComponent,
      }, {
        path: 'deposits',
        component: DepositComponent,
      }, {
        path: 'withdrawadd',
        component: WithdrawaddComponent,
      }, {
        path: 'withdraws',
        component: WithdrawComponent,
      }, {
        path: 'transferadd',
        component: TransferaddComponent,
      }, {
        path: 'transfers',
        component: TransferComponent,
      }, {
        path: 'branchdetails',
        component: BranchDetailsComponent,
      }, {
        path: 'customerdetails',
        component: CustomerDetailsComponent,
      }, {
        path: 'accountdetails',
        component: AccountDetailsComponent,
      }
      , {
        path: 'balancecheck',
        component: BalanchcheckComponent,
      }, {
        path: 'statement',
        component: StatementComponent,
      }, {
        path: 'statementview',
        component: StatementviewComponent,
      }

    ],
  },
  {
    path: 'officer',
    component: OfficerDashboardComponent,
    canActivate: [OfficerGuard],
    children: [
      { path: '', redirectTo: 'homepage', pathMatch: 'full' },
      {
        path: 'homepage',
        component: HomepageadminComponent,
      },
      {
        path: 'profile',
        component: ProfileComponent,
      },
      {
        path: 'user',
        component: UserComponent,
      },
      {
        path: 'useradd',
        component: AdduserComponent,
      }, {
        path: 'branchadd',
        component: AddbranchComponent,
      }, {
        path: 'branch',
        component: BranchComponent,
      }, {
        path: 'customeradd',
        component: CustomerAddComponent,
      }, {
        path: 'customers',
        component: CustomerComponent,
      }, {
        path: 'accountcreate',
        component: AccountAddComponent,
      }, {
        path: 'accounts',
        component: AccountComponent,
      }, {
        path: 'depositadd',
        component: DepositaddComponent,
      }, {
        path: 'deposits',
        component: DepositComponent,
      }, {
        path: 'withdrawadd',
        component: WithdrawaddComponent,
      }, {
        path: 'withdraws',
        component: WithdrawComponent,
      }, {
        path: 'transferadd',
        component: TransferaddComponent,
      }, {
        path: 'transfers',
        component: TransferComponent,
      }, {
        path: 'branchdetails',
        component: BranchDetailsComponent,
      }, {
        path: 'customerdetails',
        component: CustomerDetailsComponent,
      }, {
        path: 'accountdetails',
        component: AccountDetailsComponent,
      }
      , {
        path: 'balancecheck',
        component: BalanchcheckComponent,
      }, {
        path: 'statement',
        component: StatementComponent,
      }, {
        path: 'statementview',
        component: StatementviewComponent,
      }

    ],
  },

  { path: '', redirectTo: '/home', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
