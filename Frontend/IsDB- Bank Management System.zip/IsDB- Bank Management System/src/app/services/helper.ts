let baseUrl = 'http://localhost:8080/bank/api';
export default baseUrl;
