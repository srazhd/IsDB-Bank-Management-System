import { Component, OnInit } from '@angular/core';
import { Withdraw } from '../models/withdraw.model';
import { WithdrawService } from './withdraw.service';

@Component({
  selector: 'app-Withdraw',
  templateUrl: './Withdraw.component.html',
  styleUrls: ['./Withdraw.component.css']
})
export class WithdrawComponent implements OnInit {
  wit  =new Withdraw();
  constructor(private ws : WithdrawService) { }

  ngOnInit(): void {
    this.getWithdraws();
  }
  submitted = false;
  
  isAdd = true;
  isEdit;
 
  onSubmit() { 
    // this.submitted = true; 
    if(this.isAdd){
      this.ws.addWithdraw(this.wit);
      alert('Withdraw Save Successfull');
       this.refresh();
      }
      else{
        this.ws.updateWithdraw(this.wit);
        alert('Withdraw Save Successfull');
        this.refresh();
      }
  }

refresh(): void {
    window.location.reload();
     this.isEdit = false;
     this.isAdd =true;
}

onEdited(c: Withdraw){
  this.wit.id = c.id;
  this.wit.accno =c.accno;
  this.wit.date =c.date;
  this.wit.amount =c.amount;

  this.isEdit = true;
  this.isAdd =false;

}
  
  newStudent() {
  this.isEdit = false;
  this.isAdd =true;
  }

  
  edit(wit: Withdraw) {
     this.onEdited(wit);
  }

  delete(wit: Withdraw){
    this.ws.deleteWithdraw(wit);
    this.refresh();
  }
  withdraws: Withdraw[];
  public getWithdraws() {
    this.ws.getWithdraws().subscribe((data: Withdraw[]) => {
      this.withdraws = data;
    });
  }

}
