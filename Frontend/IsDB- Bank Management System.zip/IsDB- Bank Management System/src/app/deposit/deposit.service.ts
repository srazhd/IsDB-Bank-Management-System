import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Deposit } from '../models/deposit.model';
import { Observable } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';
 
const httpOptions = {
    headers: new HttpHeaders({
      'Content-Type':  'application/json',
      'Authorization': 'my-auth-token'
    })
  };
@Injectable({
    providedIn: 'root'
})
export class DepositService {

 

    LIVE_URI = 'http://localhost:3000';
    constructor(private httpClient: HttpClient) { }
    // getDeposits() {
    //     return this.httpClient.get(`${this.LIVE_URI}/Deposits`);
    // }
    getDeposits(): Observable<Deposit[]> {
        return this.httpClient.get<Deposit[]>(`${this.LIVE_URI}/Deposits`);
    }

    addDeposit(u: Deposit | null) {

        this.httpClient.post(`${this.LIVE_URI}/Deposits`, u)
            .subscribe(           );

            
    }

  

    /** PUT: update the hero on the server. Returns the updated hero upon success. */
updateDeposit (d: Deposit) {
    this.httpClient.put<Deposit>(`${this.LIVE_URI}/Deposits/${d.id}`, d).subscribe();
}
deleteDeposit (d: Deposit) {
    this.httpClient.delete<Deposit>(`${this.LIVE_URI}/Deposits/${d.id}`).subscribe();
}

}