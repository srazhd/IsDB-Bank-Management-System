import { Component, OnInit } from '@angular/core';
import { Deposit } from '../models/deposit.model';
import { DepositService } from './deposit.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
  dep  =new Deposit();
  constructor(private ds : DepositService) { }

  ngOnInit(): void {
    this.getDeposits();
  }
  submitted = false;
  
  isAdd = true;
  isEdit;
 
  onSubmit() { 
    // this.submitted = true; 
    if(this.isAdd){
      this.ds.addDeposit(this.dep);
      alert('Deposit Save Successfull');
       this.refresh();
      }
      else{
        this.ds.updateDeposit(this.dep);
        alert('Deposit Update Successfull');
        this.refresh();
      }
  }

refresh(): void {
    window.location.reload();
     this.isEdit = false;
     this.isAdd =true;
}

onEdited(c: Deposit){
  this.dep.id = c.id;
  this.dep.accno =c.accno;
  this.dep.date =c.date;
  this.dep.amount =c.amount;

  this.isEdit = true;
  this.isAdd =false;

}
  
  newStudent() {
  this.isEdit = false;
  this.isAdd =true;
  }

  
  edit(dep: Deposit) {
     this.onEdited(dep);
  }

  delete(dep: Deposit){
    this.ds.deleteDeposit(dep);
    this.refresh();
  }
  deposits: Deposit[];
  public getDeposits() {
    this.ds.getDeposits().subscribe((data: Deposit[]) => {
      this.deposits = data;
    });
    // console.log(this.deposits);
  }

}
