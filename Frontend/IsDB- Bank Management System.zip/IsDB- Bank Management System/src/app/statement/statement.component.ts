import { Component, OnInit } from '@angular/core';
import { WithdrawService } from '../withdraw/withdraw.service';
import { Withdraw } from '../models/withdraw.model';
import { DepositService } from '../deposit/deposit.service';
import { Deposit } from '../models/deposit.model';
import { Account } from '../models/account.model';
import { AccountService } from '../account/account.service';
@Component({
  selector: 'app-statement',
  templateUrl: './statement.component.html',
  styleUrls: ['./statement.component.css']
})
export class StatementComponent implements OnInit {

  acno : number = 1;

  acName: string= ' --';
   balance : number=0;

  constructor(private ds : DepositService,private ws : WithdrawService,private as : AccountService) { }

  ngOnInit(): void {
    
  }
  onSubmit(){
    this.deposits = [];
    this.withdraws = [];
    this.balance = 0;
    this.getBalance(this.acno);
    this.getAcName(this.acno);
  }
  deposits: Deposit[];
  withdraws: Withdraw[];

  getBalance(acno : number){
    
    
    this.ds.getDeposits().subscribe((data: Deposit[]) => {
      
      

      for( let d  of data) {
        if(this.acno ==  d.accno){
          this.balance +=  parseInt(d.amount.toString());
          this.deposits.push(d) ;
          continue;
        }else{
          continue;
        }
      };


    });
    this.ws.getWithdraws().subscribe((data: Withdraw[]) => {
      
      
    for( let w  of data) {
      if( this.acno ==  w.accno){
        this.balance -=  parseInt(w.amount.toString());
        this.withdraws.push(w) ;
        continue;
      }else{
        continue;
      }
    };


    });
    // console.log(this.deposits);
    // console.log(this.withdraws);



    
  }
  accounts: Account[];
  getAcName(acno : number){
    this.as.getAccounts().subscribe((data: Account[]) => {
      this.accounts = data;
      for( let a  of data) {
        if(a.id == this.acno  ){
          this.acName = a.name;
          break;
        }else{
          
        }
      };
    });
    
  }

  onPrint(divName) {
    const printContents = document.getElementById(divName).innerHTML;
    const originalContents = document.body.innerHTML;
    document.body.innerHTML = printContents;
    window.print();
    document.body.innerHTML = originalContents;
}

}
