import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Customer } from '../models/customer.model';
import { Observable } from 'rxjs';
 
@Injectable({
    providedIn: 'root'
})
export class CustomerService {
    LIVE_URI = 'http://localhost:3000';
    constructor(private httpClient: HttpClient) { }
    // getCustomers() {
    //     return this.httpClient.get(`${this.LIVE_URI}/Customers`);
    // }
    getCustomers(): Observable<Customer[]> {
        return this.httpClient.get<Customer[]>(`${this.LIVE_URI}/Customers`);
    }

    addCustomers(c: Customer) {
        const uri = 'http://localhost:3000';
        // const obj = {
        //   name: name,
        //   country: country,
        //   gender:gender,
        //   department:department
        // };

        this.httpClient.post(`${this.LIVE_URI}/Customers`, c)
            .subscribe(           );

            
    }

    /** PUT: update the hero on the server. Returns the updated hero upon success. */
updateCustomer (s: Customer) {
    this.httpClient.put<Customer>(`${this.LIVE_URI}/Customers/${s.id}`, s).subscribe();
}
deleteCustomer (s: Customer) {
    this.httpClient.delete<Customer>(`${this.LIVE_URI}/Customers/${s.id}`).subscribe();
}

}