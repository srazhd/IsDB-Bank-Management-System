import { Component, OnInit } from '@angular/core';
import { Customer } from '../models/customer.model';
import { CustomerService } from './customer.service';
@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {
  cus  =new Customer();
  constructor(private cs : CustomerService) { }

  ngOnInit(): void {
    this.getCustomers();
  }
  submitted = false;
  
  isAdd = true;
  isEdit;
 
  onSubmit() { 
    // this.submitted = true; 
    if(this.isAdd){
      this.cs.addCustomers(this.cus);
      alert('Customer Insert Successfull');
  
       this.refresh();
      }
      else{
        this.cs.updateCustomer(this.cus);
        alert('Customer Update Successfull');
        this.refresh();
      }
  }

refresh(): void {
    window.location.reload();
     this.isEdit = false;
     this.isAdd =true;
}

onEdited(c: Customer){
  this.cus.id = c.id;
  this.cus.name =c.name;
  this.cus.age =c.age;
  this.cus.address =c.address;
  this.cus.mobile = c.mobile;
  this.isEdit = true;
  this.isAdd =false;

}
  
  newStudent() {
  this.isEdit = false;
  this.isAdd =true;
  }

  
  edit(cus: Customer) {
     this.onEdited(cus);
  }

  delete(cus: Customer){
    this.cs.deleteCustomer(cus);
    this.refresh();
  }
 customers: Customer[];
  public getCustomers() {
    this.cs.getCustomers().subscribe((data: Customer[]) => {
      this.customers = data;
    });
  }
 
}
