import { Component, OnInit } from '@angular/core';
import { UserService } from './user.service';
import { User } from '../models/user.model';
import { ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  u : User = new User( );
  ulog : User = new User ( );
  email : string ;
  password : string  ;

  isSignUp = false;

  isSignIn = true;
  // private toastr: ToastrService

  constructor(private us: UserService, private router: Router) { }

  ngOnInit(): void {
    if(sessionStorage.getItem('name')){
      this.router.navigate(['/home']);
    }
  }




  signIn(){
    this.isSignUp = false;
    this.isSignIn = true;
  }

  signUp(){
    this.isSignUp = true;
    this.isSignIn = false;
  }
  @ViewChild('userForm', {static: false}) userForm ?: NgForm ;
  registration(){
    
    this.us.addUser(this.u);
    alert('Registration Successfull');
    // this.toastr.error('Registration Successfull');
    this.userForm?.resetForm();
  }
  users : User[] = [];
  login(){
    this.email = this.u.email;
    this.password = this.u.password;

    this.ulog.password = this.u.password;
    this.ulog.email = this.u.email;  
      this.us.getUsers().subscribe(
      ( data ) => {
        //  this.users = data;
         for( let u  of data) {
          if(u.email == this.email  ){
            if( u.password == <string>this.password  ){
              sessionStorage.setItem('name', u.name);
              alert('Login Successfully');
              this.router.navigate(['/home']);
              break;
            }else{
              alert('Email or Password Dose Not Match');
              break;
            }
          }else{
            
          }
        };
        
      });
      
   




    
  }
  public getStudents() {
    this.us.getUsers().subscribe((data: any) => {
      this.users = data;
    });
  }
}
