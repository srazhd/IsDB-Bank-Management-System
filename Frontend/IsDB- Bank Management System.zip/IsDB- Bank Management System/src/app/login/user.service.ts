import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/user.model';
import { Observable } from 'rxjs';
import { HttpHeaders } from '@angular/common/http';
 
const httpOptions = {
    headers: new HttpHeaders({
      'Content-Type':  'application/json',
      'Authorization': 'my-auth-token'
    })
  };
@Injectable({
    providedIn: 'root'
})
export class UserService {

 

    LIVE_URI = 'http://localhost:3000';
    constructor(private httpClient: HttpClient) { }
    // getUsers() {
    //     return this.httpClient.get(`${this.LIVE_URI}/users`);
    // }
    getUsers(): Observable<User[]> {
        return this.httpClient.get<User[]>(`${this.LIVE_URI}/users`);
    }
    addUser(u: User | null) {

        this.httpClient.post(`${this.LIVE_URI}/users`, u)
            .subscribe(           );

            
    }

  

    /** PUT: update the hero on the server. Returns the updated hero upon success. */
updateStudent (s: User) {
    this.httpClient.put<User>(`${this.LIVE_URI}/students/${s.id}`, s).subscribe();
}
deleteStudent (s: User) {
    this.httpClient.delete<User>(`${this.LIVE_URI}/students/${s.id}`).subscribe();
}

}