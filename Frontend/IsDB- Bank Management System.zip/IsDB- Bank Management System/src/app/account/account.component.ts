import { Component, OnInit } from '@angular/core';
import { Account } from '../models/account.model';
import { AccountService } from './account.service';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {

  acc  =new Account();
  constructor(private as : AccountService) { }

  ngOnInit(): void {
    this.getAccounts();
  }
  submitted = false;
  
  isAdd = true;
  isEdit;
 
  onSubmit() { 
    // this.submitted = true; 
    if(this.isAdd){
      this.as.addAccounts(this.acc);
      alert('Account Insert Successfull');
       this.refresh();
      }
      else{
        this.as.updateAccount(this.acc);
        alert('Account Update Successfull');
        this.refresh();
      }
  }

refresh(): void {
    window.location.reload();
     this.isEdit = false;
     this.isAdd =true;
}

onEdited(a: Account){
  this.acc.id = a.id;
  this.acc.customerid =a.customerid;
  this.acc.name =a.name;
  
  this.isEdit = true;
  this.isAdd =false;

}
  
  newStudent() {
  this.isEdit = false;
  this.isAdd =true;
  }

  
  edit(cus: Account) {
     this.onEdited(cus);
  }

  delete(cus: Account){
    this.as.deleteAccount(cus);
    this.refresh();
  }
  accounts: Account[];
  public getAccounts() {
    this.as.getAccounts().subscribe((data: Account[]) => {
      this.accounts = data;
    });
  }

}
