import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Account } from '../models/account.model';
import { Observable } from 'rxjs';
 
@Injectable({
    providedIn: 'root'
})
export class AccountService {
    LIVE_URI = 'http://localhost:3000';
    constructor(private httpClient: HttpClient) { }
    // getAccounts() {
    //     return this.httpClient.get(`${this.LIVE_URI}/Accounts`);
    // }
    getAccounts(): Observable<Account[]> {
        return this.httpClient.get<Account[]>(`${this.LIVE_URI}/Accounts`);
    }

    addAccounts(c: Account) {
        const uri = 'http://localhost:3000';
        // const obj = {
        //   name: name,
        //   country: country,
        //   gender:gender,
        //   department:department
        // };

        this.httpClient.post(`${this.LIVE_URI}/Accounts`, c)
            .subscribe(           );

            
    }

    /** PUT: update the hero on the server. Returns the updated hero upon success. */
updateAccount (s: Account) {
    this.httpClient.put<Account>(`${this.LIVE_URI}/Accounts/${s.id}`, s).subscribe();
}
deleteAccount (s: Account) {
    this.httpClient.delete<Account>(`${this.LIVE_URI}/Accounts/${s.id}`).subscribe();
}

}