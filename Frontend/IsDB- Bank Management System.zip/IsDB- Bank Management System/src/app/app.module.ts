import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';

import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import {MatBadgeModule} from '@angular/material/badge';
import {MatBottomSheetModule} from '@angular/material/bottom-sheet';
import {MatButtonModule} from '@angular/material/button';
import {MatButtonToggleModule} from '@angular/material/button-toggle';
import {MatCardModule} from '@angular/material/card';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatChipsModule} from '@angular/material/chips';
import {MatStepperModule} from '@angular/material/stepper';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatDialogModule} from '@angular/material/dialog';
import {MatDividerModule} from '@angular/material/divider';
import {MatExpansionModule} from '@angular/material/expansion';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatIconModule} from '@angular/material/icon';
import {MatInputModule} from '@angular/material/input';
import {MatListModule} from '@angular/material/list';
import {MatMenuModule} from '@angular/material/menu';
import {MatNativeDateModule, MatRippleModule} from '@angular/material/core';
import {MatPaginatorModule} from '@angular/material/paginator';
import {MatProgressBarModule} from '@angular/material/progress-bar';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import {MatRadioModule} from '@angular/material/radio';
import {MatSelectModule} from '@angular/material/select';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatSliderModule} from '@angular/material/slider';
import {MatSlideToggleModule} from '@angular/material/slide-toggle';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import {MatSortModule} from '@angular/material/sort';
import {MatTableModule} from '@angular/material/table';
import {MatTabsModule} from '@angular/material/tabs';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatTreeModule} from '@angular/material/tree';
import {OverlayModule} from '@angular/cdk/overlay';


import { MatFormFieldModule } from '@angular/material/form-field';


import { LoginComponent } from './components/pages/auth/login/login.component';
import { HomeComponent } from './home/home.component';
import { FormsModule }   from '@angular/forms';

import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { CacheInterceptor } from './cache.interceptor';
import { CustomersComponent } from './customers/customers.component';


import { BalanceComponent } from './balance/balance.component';
import { StatementComponent } from './statement/statement.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { SignupComponent } from './components/pages/auth/signup/signup.component';
import { ProfileComponent } from './components/admin/profile/profile.component';
import { DashboardComponent } from './components/admin/dashboard/dashboard.component';
import { AdduserComponent } from './components/admin/user-add/adduser.component';
import { UserComponent } from './components/admin/user/user.component';
 
import { authInterceptorProviders } from './services/auth.interceptor';
import { AddbranchComponent } from './components/admin/branch-add/addbranch.component';
import { BranchComponent } from './components/admin/branch/branch.component';
import { BranchDetailsComponent } from './components/admin/branch-details/branch-details.component';
 
import { AccountDetailsComponent } from './components/admin/account-details/account-details.component';
 
import { CustomerComponent } from './components/admin/customer/customer.component';
import { CustomerDetailsComponent } from './components/admin/customer-details/customer-details.component';
import { CustomerAddComponent } from './components/admin/customer-add/customer-add.component';
import { AccountAddComponent } from './components/admin/account-add/account-add.component';
import { CommonModule } from '@angular/common';
import { AccountComponent } from './components/admin/account/account.component';
import { DepositaddComponent } from './components/admin/depositadd/depositadd.component';
import { WithdrawaddComponent } from './components/admin/withdrawadd/withdrawadd.component';
import { DepositComponent } from './components/admin/deposit/deposit.component';
import { WithdrawComponent } from './components/admin/withdraw/withdraw.component';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    CustomersComponent,
    
    DepositComponent,
    WithdrawComponent,
    BalanceComponent,
    StatementComponent,
    HeaderComponent,
    FooterComponent,
    SignupComponent,
    DashboardComponent,
    ProfileComponent,
    AdduserComponent,
    UserComponent, 
    AddbranchComponent,
    BranchComponent,
    BranchDetailsComponent,     
    AccountDetailsComponent,     
    CustomerComponent,
    CustomerDetailsComponent,
    CustomerAddComponent,
    AccountAddComponent,
    AccountComponent,
    DepositaddComponent,
    WithdrawaddComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule, 
    MatAutocompleteModule,
    MatBadgeModule,
    MatBottomSheetModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatStepperModule,
    MatDatepickerModule,
    MatDialogModule,
    MatDividerModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatTreeModule,
    OverlayModule,
    CommonModule,

    MatFormFieldModule
  ],
  exports: [
    
  ],
  providers: [authInterceptorProviders],
  bootstrap: [AppComponent]
})
export class AppModule { }
