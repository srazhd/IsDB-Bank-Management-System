import { Component, OnInit } from '@angular/core';
import { WithdrawService } from '../withdraw/withdraw.service';
import { Withdraw } from '../models/withdraw.model';
import { DepositService } from '../deposit/deposit.service';
import { Deposit } from '../models/deposit.model';
import { Account } from '../models/account.model';
import { AccountService } from '../account/account.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {


  

  acName: string= ' --';
  balance : number=0;
  totalDeposit : number=0;
  totalWithdraw : number=0;

  constructor(private ds : DepositService,private ws : WithdrawService,private as : AccountService) { }

  ngOnInit(): void {
    this.getBalance();
    this.getDepWit( );
  }
  onSubmit(){
    this.deposits = [];
    this.withdraws = [];
    this.balance = 0;
    this.getBalance( );
    
  }
  deposits: Deposit[];
  withdraws: Withdraw[];

  getBalance( ){
    
    this.ds.getDeposits().subscribe((data: Deposit[]) => {
     
      for( let d  of data) {
          this.totalDeposit += parseInt(d.amount.toString());
           
      };

    });
    this.ws.getWithdraws().subscribe((data: Withdraw[]) => {
      
    for( let w  of data) {
       this.totalWithdraw += parseInt(w.amount.toString());
          
    };

    });
    
  }

  
  getDepWit( ){
    
    this.ds.getDeposits().subscribe((data: Deposit[]) => {
      
          this.deposits = data;
       
    });
    this.ws.getWithdraws().subscribe((data: Withdraw[]) => {
        
        this.withdraws = data ;
     
    });
    
  }
  

}
