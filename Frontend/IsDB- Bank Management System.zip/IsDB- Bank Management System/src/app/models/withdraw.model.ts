export class Withdraw {
     id : number  ;
     accno: number  ;
     date: string  ;
     amount: number  ;
      
}