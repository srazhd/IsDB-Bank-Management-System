export class Account {
    id: number;
    customerid: number;
    name: string;
}