export class Deposit {
     id : number  ;
     accno: number  ;
     date: string  ;
     amount: number  ;
      
}