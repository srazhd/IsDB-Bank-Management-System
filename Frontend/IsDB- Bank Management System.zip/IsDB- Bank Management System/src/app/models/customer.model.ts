export class Customer {
     id: number;
     name: string;
     age: number;
     address: string;
     mobile: number;
    
    
}