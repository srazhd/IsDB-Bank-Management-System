import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WithdrawaddComponent } from './withdrawadd.component';

describe('WithdrawaddComponent', () => {
  let component: WithdrawaddComponent;
  let fixture: ComponentFixture<WithdrawaddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WithdrawaddComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WithdrawaddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
