import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-withdrawadd',
  templateUrl: './withdrawadd.component.html',
  styleUrls: ['./withdrawadd.component.css']
})
export class WithdrawaddComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
