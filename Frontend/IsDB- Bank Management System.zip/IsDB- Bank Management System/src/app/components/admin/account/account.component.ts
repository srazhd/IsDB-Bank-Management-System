import { Component, OnInit } from '@angular/core';
import { AccountService } from 'src/app/services/account.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent implements OnInit {
 accounts = [];
 
  constructor(private accountService :AccountService) { }

  ngOnInit(): void {
    this.accountService.accounts().subscribe((data:any)=>{
      this.accounts= data.content;
      console.log(this.accounts);
   })
  }
  edit(account){

  }
  delete(id){
    this.accountService.deleteAccount(id).subscribe(
      (data) => {
        Swal.fire('Success', 'Account id deleted', 'success');
        
      },

      (error) => {
        Swal.fire('Error!! ', 'Error while delete Account', 'error');
        console.log(error);
      }
     );
  }

}
