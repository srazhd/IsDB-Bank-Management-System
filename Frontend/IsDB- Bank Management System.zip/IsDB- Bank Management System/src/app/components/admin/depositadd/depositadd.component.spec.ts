import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DepositaddComponent } from './depositadd.component';

describe('DepositaddComponent', () => {
  let component: DepositaddComponent;
  let fixture: ComponentFixture<DepositaddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DepositaddComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DepositaddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
