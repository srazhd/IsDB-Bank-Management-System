import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import Swal from 'sweetalert2';
 

@Component({
  selector: 'app-adduser',
  templateUrl: './adduser.component.html',
  styleUrls: ['./adduser.component.css']
})
export class AdduserComponent implements OnInit {
  users=[];
  userData = {
        "name": "",
        "email": "",
        "username": "",
        "password": "",
        "userAddress": {
            "streetName": "",
            "city": "",
            "country": "",
            "zipCode": ""
        },
        "roles": [
            {
                "name": ""
            }
        ]
  };
  constructor(private userService :UserService) { }

  ngOnInit(): void {
  this.userService.users().subscribe((data:any)=>{
     this.users= data;
  })
  }
  onSubmit(){
     
     this.userService.addUser(this.userData).subscribe(
      (data) => {
        Swal.fire('Success', 'User is added', 'success');
        this.userData = {
          "name": "",
        "email": "",
        "username": "",
        "password": "",
        "userAddress": {
            "streetName": "",
            "city": "",
            "country": "",
            "zipCode": "100"
        },
        "roles": [
            {
                "name": ""
            }
        ]
        };
      },

      (error) => {
        Swal.fire('Error!! ', 'Error while adding User', 'error');
        console.log(error);
      }
     );
  
    }

}
